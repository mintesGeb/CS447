window.onload = function(){
    console.log(window.location.href);
    console.log(sessionStorage.getItem('accessToken'));
}